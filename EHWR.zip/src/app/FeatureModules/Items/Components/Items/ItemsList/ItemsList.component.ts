import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ItemsList',
  templateUrl: './ItemsList.component.html',
  styleUrls: ['./ItemsList.component.scss']
})
export class ItemsListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
