import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-AddItems',
  templateUrl: './AddItems.component.html',
  styleUrls: ['./AddItems.component.scss']
})
export class AddItemsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
