import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-CustomersList',
  templateUrl: './CustomersList.component.html',
  styleUrls: ['./CustomersList.component.scss']
})
export class CustomersListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
