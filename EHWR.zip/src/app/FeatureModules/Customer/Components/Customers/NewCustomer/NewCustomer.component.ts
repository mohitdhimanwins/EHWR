import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-NewCustomer',
  templateUrl: './NewCustomer.component.html',
  styleUrls: ['./NewCustomer.component.scss']
})
export class NewCustomerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
