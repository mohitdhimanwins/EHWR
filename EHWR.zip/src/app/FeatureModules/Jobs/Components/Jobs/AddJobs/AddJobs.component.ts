import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-AddJobs',
  templateUrl: './AddJobs.component.html',
  styleUrls: ['./AddJobs.component.scss']
})
export class AddJobsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
