import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-JobsList',
  templateUrl: './JobsList.component.html',
  styleUrls: ['./JobsList.component.scss']
})
export class JobsListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
