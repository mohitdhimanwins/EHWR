import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Jobs',
  templateUrl: './Jobs.component.html',
  styleUrls: ['./Jobs.component.scss']
})
export class JobsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
